import csv
url_s = []
path1 = 'corona_weibo.csv' 
path2 = 'weibo_username_original_pic_profile_url.csv'
def deal_date():
    with open (path1,'r',encoding = 'utf-8') as csvfile1,open(path2,'r',encoding = 'utf-8') as csvfile2:
        corona_weibo = csv.reader(csvfile1)
        weibo_list = list(csv.reader(csvfile2))
        # print(weibo_list[0][1])
        for p_corona in corona_weibo:
            # i = 0
            # while i<len(weibo_list):
            #     if p_corona[1][:-4] in weibo_list[i][1]:
            #         print(weibo_list[i])
            #         I.append(weibo_list[i][2])
            #         i += 1
            for p_weibo in weibo_list:
                if p_corona[1][:-4] in p_weibo[1]:
                    # print(p_weibo)
                    url_s.append(p_weibo[2])

deal_date()
url_s = list(set(url_s))
print(len(url_s))
print(url_s[0])
start_urls = []
for url in url_s:
    start_urls.append("https:"+url)
print(start_urls)
# corona_weibo = csv.reader(open('数据\\corona_weibo.csv','r'))
# weibo_list = csv.reader(open('数据\\weibo_username_original_pic_profile_url.csv','r',encoding = 'utf-8'))


# for row in corona_weibo:
#     for weibo_url in weibo_list:
#         if row[1][:-4] in weibo_url[1]:
#             I.append(weibo_url[2])

# I = list(set(I))


# print(I)
# print(len(I))
