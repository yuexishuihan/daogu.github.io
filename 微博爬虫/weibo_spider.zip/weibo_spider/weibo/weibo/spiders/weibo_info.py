# -*- coding: utf-8 -*-
import scrapy
import re
from lxml import etree
import deal_01
# from io import StringIO
deal_01.deal_date()
deal_01.url_s = list(set(deal_01.url_s))
# print(len(url_s))
# print(url_s[0])
class WeiboInfoSpider(scrapy.Spider):
    name = 'weibo_info'
    allowed_domains = ['weibo.com']
    start_urls = []
    for url in deal_01.url_s:
        start_urls.append("https:"+url)


    # start_urls = ['https://weibo.com/2546745464?refer_flag=1001030103_']
    # start_urls = "https:"+urls[0]
    # print(start_urls)

    def start_requests(self):
        cookies = "SINAGLOBAL=5898199635098.043.1547381062368; un=18336390046; wvr=6; Ugrow-G0=7e0e6b57abe2c2f76f677abd9a9ed65d; SSOLoginState=1548558811; SCF=Arl60IOgPzf9O62T8D-xzv8D58Uf6ilOfZXkxmEp-8JubzX2Ghq9Rbgk6cVcxSjvrSjYVFcePTlFOv5iYCqHKgU.; SUB=_2A25xSVGLDeRhGeNM41oZ-CfOyjyIHXVSP8RDrDV8PUNbmtBeLVrAkW9NSeXmByanhcpP4jaee0X-Pxb_qt_td8O8; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WFaSWTzj71pJp2ddj41gQux5JpX5KMhUgL.Fo-E1hnR1h.EeK52dJLoI7DpUgHydJxuIg4r; SUHB=0y0ZiNigY_1FcQ; ALF=1580094810; YF-V5-G0=f59276155f879836eb028d7dcd01d03c; _s_tentry=login.sina.com.cn; UOR=,,spr_sinamkt_buy_uc123_weibo_t001; Apache=7532728062427.116.1548558816288; ULV=1548558816348:6:6:1:7532728062427.116.1548558816288:1548469211346; YF-Page-G0=c704b1074605efc315869695a91e5996; wb_view_log_5288889210=1366*7681"
        cookies = {i.split("=")[0]:i.split("=")[1] for i in cookies.split("; ")}
        for user_url in self.start_urls:
            yield scrapy.Request(
                user_url,
                callback = self.parse,
                cookies = cookies
            )

    def parse(self, response):
        r = response.body.decode()

        # print(re.findall(r'href=.*?pedit_more',r))
        info = str(re.findall(r'href=\\"\\/p\\/.*?pedit_more',r))
        print(info)
        print(info[17:33])
        info_url = "https://weibo.com/p/"+info[17:33]+"/info?mod=pedit_more"
        print (info_url)
        yield scrapy.Request(info_url,callback=self.parse_detial)
    
    def parse_detial(self,response):
        # print(response.body.decode())
        
        # print(user_info)
        s = response.body.decode("utf-8")
        # print(s)
        user_info = str(re.findall(r'基本信息.*div?',s))
        print("*"*100)
        user_info = user_info.replace("\\","").replace("rn","").strip()
        html = etree.HTML(user_info)
        print(html)
        ret1 = html.xpath("//li/span[1]/text()")
        print(len(ret1))
        print("*"*100)
        ret2 = html.xpath("//li/span[2]/text()")
        print(len(ret1))
        ret3 = html.xpath("//li/span/a/text()")
        print(ret3)
        item = dict(map(lambda x,y:[x,y],ret1,ret2))
        # print(dic)
        print(item)
        yield item
